import pandas as pd

df = pd.read_csv('/opt/airflow/data/extracted.csv')

# rename
df = df.rename(columns={
    "Date_of_Journey": "date",
    "Dep_Time": "departure_time",
    "Arrival_Time": "arrival_time",
    "Total_Stops": "stops",
    "Additional_Info": "info"
})

df.columns = df.columns.str.lower()

# nettoyage
df = df.dropna(subset=['route'])

# mapping stops
map_stops = {
    "non-stop": 0,
    "1 stop": 1,
    "2 stops": 2,
    "3 stops": 3,
    "4 stops": 4
}

df["stops_num"] = df["stops"].map(map_stops)

# datetime
df["datetime_departure"] = pd.to_datetime(
    df["date"] + " " + df["departure_time"],
    format="%d/%m/%Y %H:%M"
)

# duration
def duration_to_minutes(duration):
    h = 0
    m = 0
    if 'h' in duration:
        h = int(duration.split('h')[0])
    if 'm' in duration:
        m = int(duration.split('h')[-1].replace('m','').strip())
    return h * 60 + m

df["duration_min"] = df["duration"].apply(duration_to_minutes)

# arrival
df["datetime_arrival"] = df["datetime_departure"] + pd.to_timedelta(df["duration_min"], unit="m")

# clean final
df = df.drop(columns=["date", "stops", "departure_time", "arrival_time", "duration", "route"])

df.to_csv('/opt/airflow/data/transformed.csv', index=False)