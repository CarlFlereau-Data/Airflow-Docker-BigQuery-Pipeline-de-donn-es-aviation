import pandas as pd

df = pd.read_csv('/opt/airflow/data/data_flight.csv')
df.to_csv('/opt/airflow/data/extracted.csv', index=False)