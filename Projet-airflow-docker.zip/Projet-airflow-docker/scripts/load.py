import pandas as pd
from google.cloud import bigquery

# lire les données transformées
df = pd.read_csv("/opt/airflow/data/transformed.csv")

# créer le client BigQuery
client = bigquery.Client(project="projet-pipeline-491100")

# table cible
table_id = "projet-pipeline-491100.aviation.flights"

# envoi des données
job = client.load_table_from_dataframe(df, table_id)

job.result()

print("Données envoyées dans BigQuery")