# on importe les éléments nécessaires pour créer un pipeline Airflow
from airflow import DAG
from airflow.operators.bash import BashOperator
from datetime import datetime

# ici on définit notre DAG (donc notre pipeline)
with DAG(
    dag_id='aviation_pipeline',  # nom du pipeline dans Airflow
    start_date=datetime(2024, 1, 1),  # date à partir de laquelle le pipeline peut s’exécuter
    schedule_interval='@weekly',  # le pipeline se lance automatiquement chaque semaine
    catchup=False  # évite de lancer les anciennes exécutions (pour éviter des doublons)
) as dag:

    # première étape : extraction des données
    extract = BashOperator(
        task_id='extract',  # nom de la tâche dans Airflow
        bash_command='python /opt/airflow/scripts/extract.py'  # script exécuté
    )

    # deuxième étape : transformation des données
    transform = BashOperator(
        task_id='transform',
        bash_command='python /opt/airflow/scripts/transform.py'
    )

    # troisième étape : chargement / output des données
    load = BashOperator(
        task_id='load',
        bash_command='python /opt/airflow/scripts/load.py'
    )

    # ici on définit l’ordre des tâches :
    # extract → transform → load
    extract >> transform >> load